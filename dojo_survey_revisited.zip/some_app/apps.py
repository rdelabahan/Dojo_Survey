from django.apps import AppConfig


class SomeAppConfig(AppConfig):
    name = 'some_app'
